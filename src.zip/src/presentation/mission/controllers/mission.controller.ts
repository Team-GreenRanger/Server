import { 
  Controller, 
  Get, 
  Post, 
  Patch, 
  Param, 
  Body, 
  Query, 
  UseGuards,
  Request
} from '@nestjs/common';
import { 
  ApiTags, 
  ApiOperation, 
  ApiResponse, 
  ApiBearerAuth,
  ApiParam,
  ApiQuery 
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { AssignMissionUseCase } from '../../../application/mission/use-cases/assign-mission.use-case';
import { SubmitMissionUseCase } from '../../../application/mission/use-cases/submit-mission.use-case';
import { VerifyMissionUseCase } from '../../../application/mission/use-cases/verify-mission.use-case';
import { GetMissionsUseCase } from '../../../application/mission/use-cases/get-missions.use-case';
import { GetMissionByIdUseCase } from '../../../application/mission/use-cases/get-mission-by-id.use-case';
import { GetUserMissionsUseCase } from '../../../application/mission/use-cases/get-user-missions.use-case';
import { GetDailyMissionsUseCase } from '../../../application/mission/use-cases/get-daily-missions.use-case';
import { ClaudeService } from '../../../infrastructure/external-apis/claude/claude.service';
import { NotificationService } from '../../../application/notification/services/notification.service';
import { 
  MissionResponseDto,
  UserMissionResponseDto,
  AssignMissionDto,
  SubmitMissionDto,
  VerifyMissionDto,
  MissionStatusDto,
  UserMissionStatusDto
} from '../../../application/mission/dto/mission.dto';

@ApiTags('Missions')
@Controller('missions')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class MissionController {
  constructor(
    private readonly assignMissionUseCase: AssignMissionUseCase,
    private readonly submitMissionUseCase: SubmitMissionUseCase,
    private readonly verifyMissionUseCase: VerifyMissionUseCase,
    private readonly getMissionsUseCase: GetMissionsUseCase,
    private readonly getMissionByIdUseCase: GetMissionByIdUseCase,
    private readonly getUserMissionsUseCase: GetUserMissionsUseCase,
    private readonly getDailyMissionsUseCase: GetDailyMissionsUseCase,
    private readonly claudeService: ClaudeService,
    private readonly notificationService: NotificationService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Get all available missions' })
  @ApiResponse({ 
    status: 200, 
    description: 'List of missions', 
    type: [MissionResponseDto] 
  })
  @ApiQuery({ name: 'status', enum: MissionStatusDto, required: false })
  @ApiQuery({ name: 'type', required: false })
  async getMissions(
    @Query('status') status?: MissionStatusDto,
    @Query('type') type?: string,
  ): Promise<MissionResponseDto[]> {
    const result = await this.getMissionsUseCase.execute({
      status: status as any,
      type,
    });

    return result.missions.map(mission => ({
      id: mission.id,
      title: mission.title,
      description: mission.description,
      type: mission.type as any,
      difficulty: mission.difficulty as any,
      co2ReductionAmount: mission.co2ReductionAmount,
      creditReward: mission.creditReward,
      imageUrl: mission.imageUrl,
      instructions: mission.instructions,
      verificationCriteria: mission.verificationCriteria,
      status: mission.status as any,
      createdAt: mission.createdAt,
    }));
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get mission by ID' })
  @ApiParam({ name: 'id', description: 'Mission ID' })
  @ApiResponse({ 
    status: 200, 
    description: 'Mission details', 
    type: MissionResponseDto 
  })
  async getMissionById(@Param('id') id: string): Promise<MissionResponseDto> {
    const result = await this.getMissionByIdUseCase.execute({ id });
    const mission = result.mission;

    return {
      id: mission.id,
      title: mission.title,
      description: mission.description,
      type: mission.type as any,
      difficulty: mission.difficulty as any,
      co2ReductionAmount: mission.co2ReductionAmount,
      creditReward: mission.creditReward,
      imageUrl: mission.imageUrl,
      instructions: mission.instructions,
      verificationCriteria: mission.verificationCriteria,
      status: mission.status as any,
      createdAt: mission.createdAt,
    };
  }

  @Post('assign')
  @ApiOperation({ summary: 'Assign mission to current user' })
  @ApiResponse({ 
    status: 201, 
    description: 'Mission assigned successfully', 
    type: UserMissionResponseDto 
  })
  async assignMission(
    @Request() req: any,
    @Body() assignMissionDto: AssignMissionDto,
  ): Promise<UserMissionResponseDto> {
    const userId = req.user.sub; // From JWT payload
    
    const userMission = await this.assignMissionUseCase.execute({
      userId,
      missionId: assignMissionDto.missionId,
      targetProgress: assignMissionDto.targetProgress,
    });

    return {
      id: userMission.id,
      userId: userMission.userId,
      missionId: userMission.missionId,
      status: userMission.status as unknown as UserMissionStatusDto,
      currentProgress: userMission.currentProgress,
      targetProgress: userMission.targetProgress,
      submissionImageUrls: userMission.submissionImageUrls,
      submissionNote: userMission.submissionNote,
      verificationNote: userMission.verificationNote,
      submittedAt: userMission.submittedAt,
      verifiedAt: userMission.verifiedAt,
      completedAt: userMission.completedAt,
      assignedAt: userMission.assignedAt,
    };
  }

  @Get('user/daily-missions')
  @ApiOperation({ summary: 'Get daily missions for current user (assigns if not exists)' })
  @ApiResponse({ 
    status: 200, 
    description: 'Daily missions for user', 
    type: [UserMissionResponseDto] 
  })
  async getDailyMissions(@Request() req: any): Promise<UserMissionResponseDto[]> {
    const userId = req.user.sub;
    
    const result = await this.getDailyMissionsUseCase.execute({ userId });

    return result.userMissions.map(userMission => ({
      id: userMission.id,
      userId: userMission.userId,
      missionId: userMission.missionId,
      status: userMission.status as any,
      currentProgress: userMission.currentProgress,
      targetProgress: userMission.targetProgress,
      submissionImageUrls: userMission.submissionImageUrls,
      submissionNote: userMission.submissionNote,
      verificationNote: userMission.verificationNote,
      submittedAt: userMission.submittedAt,
      verifiedAt: userMission.verifiedAt,
      completedAt: userMission.completedAt,
      assignedAt: userMission.assignedAt,
    }));
  }

  @Get('user/missions')
  @ApiOperation({ summary: 'Get current user missions' })
  @ApiResponse({ 
    status: 200, 
    description: 'User missions', 
    type: [UserMissionResponseDto] 
  })
  @ApiQuery({ name: 'status', enum: UserMissionStatusDto, required: false })
  async getUserMissions(
    @Request() req: any,
    @Query('status') status?: UserMissionStatusDto,
  ): Promise<UserMissionResponseDto[]> {
    const userId = req.user.sub;
    
    const result = await this.getUserMissionsUseCase.execute({
      userId,
      status: status as any,
    });

    return result.userMissions.map(userMission => ({
      id: userMission.id,
      userId: userMission.userId,
      missionId: userMission.missionId,
      status: userMission.status as any,
      currentProgress: userMission.currentProgress,
      targetProgress: userMission.targetProgress,
      submissionImageUrls: userMission.submissionImageUrls,
      submissionNote: userMission.submissionNote,
      verificationNote: userMission.verificationNote,
      submittedAt: userMission.submittedAt,
      verifiedAt: userMission.verifiedAt,
      completedAt: userMission.completedAt,
      assignedAt: userMission.assignedAt,
    }));
  }

  @Patch('user-missions/:id/submit')
  @ApiOperation({ summary: 'Submit mission evidence with auto verification' })
  @ApiParam({ name: 'id', description: 'User Mission ID' })
  @ApiResponse({ 
    status: 200, 
    description: 'Mission submitted and verified automatically', 
    type: UserMissionResponseDto 
  })
  async submitMission(
    @Request() req: any,
    @Param('id') userMissionId: string,
    @Body() submitMissionDto: SubmitMissionDto,
  ): Promise<UserMissionResponseDto> {
    const userId = req.user.sub;
    
    // Submit mission first
    const userMission = await this.submitMissionUseCase.execute({
      userMissionId,
      imageUrls: submitMissionDto.imageUrls,
      note: submitMissionDto.note,
    });

    // Auto-verify using Claude API
    try {
      const verificationResult = await this.claudeService.verifyMissionEvidence(
        userMissionId,
        submitMissionDto.imageUrls,
        submitMissionDto.note
      );

      // Auto-approve or reject based on Claude's assessment
      const verifyResult = await this.verifyMissionUseCase.execute({
        userMissionId,
        isApproved: verificationResult.isValid,
        verificationNote: verificationResult.reasoning,
      });

      // Send notification based on result
      if (verificationResult.isValid) {
        // Get mission details for notification
        const missionResult = await this.getMissionByIdUseCase.execute({ 
          id: userMission.missionId 
        });
        
        await this.notificationService.createMissionCompletedNotification(
          userId,
          missionResult.mission.title,
          missionResult.mission.creditReward
        );
      }

      return {
        id: verifyResult.userMission.id,
        userId: verifyResult.userMission.userId,
        missionId: verifyResult.userMission.missionId,
        status: verifyResult.userMission.status as unknown as UserMissionStatusDto,
        currentProgress: verifyResult.userMission.currentProgress,
        targetProgress: verifyResult.userMission.targetProgress,
        submissionImageUrls: verifyResult.userMission.submissionImageUrls,
        submissionNote: verifyResult.userMission.submissionNote,
        verificationNote: verifyResult.userMission.verificationNote,
        submittedAt: verifyResult.userMission.submittedAt,
        verifiedAt: verifyResult.userMission.verifiedAt,
        completedAt: verifyResult.userMission.completedAt,
        assignedAt: verifyResult.userMission.assignedAt,
      };
    } catch (error) {
      console.error('Auto-verification failed:', error);
      
      // Return submitted mission if auto-verification fails
      return {
        id: userMission.id,
        userId: userMission.userId,
        missionId: userMission.missionId,
        status: userMission.status as unknown as UserMissionStatusDto,
        currentProgress: userMission.currentProgress,
        targetProgress: userMission.targetProgress,
        submissionImageUrls: userMission.submissionImageUrls,
        submissionNote: userMission.submissionNote,
        verificationNote: 'Auto-verification failed, pending manual review',
        submittedAt: userMission.submittedAt,
        verifiedAt: userMission.verifiedAt,
        completedAt: userMission.completedAt,
        assignedAt: userMission.assignedAt,
      };
    }
  }

  @Patch('user-missions/:id/verify')
  @ApiOperation({ summary: 'Verify submitted mission (Admin only)' })
  @ApiParam({ name: 'id', description: 'User Mission ID' })
  @ApiResponse({ 
    status: 200, 
    description: 'Mission verified successfully', 
    type: UserMissionResponseDto 
  })
  async verifyMission(
    @Param('id') userMissionId: string,
    @Body() verifyMissionDto: VerifyMissionDto,
  ): Promise<UserMissionResponseDto> {
    const result = await this.verifyMissionUseCase.execute({
      userMissionId,
      isApproved: verifyMissionDto.decision === 'approved',
      verificationNote: verifyMissionDto.verificationNote,
    });

    return {
      id: result.userMission.id,
      userId: result.userMission.userId,
      missionId: result.userMission.missionId,
      status: result.userMission.status as unknown as UserMissionStatusDto,
      currentProgress: result.userMission.currentProgress,
      targetProgress: result.userMission.targetProgress,
      submissionImageUrls: result.userMission.submissionImageUrls,
      submissionNote: result.userMission.submissionNote,
      verificationNote: result.userMission.verificationNote,
      submittedAt: result.userMission.submittedAt,
      verifiedAt: result.userMission.verifiedAt,
      completedAt: result.userMission.completedAt,
      assignedAt: result.userMission.assignedAt,
    };
  }
}
